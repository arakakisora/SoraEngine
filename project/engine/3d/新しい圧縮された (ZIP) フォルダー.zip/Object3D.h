#pragma once
#include "Vector2.h"
#include "Vector3.h"
#include "Vector4.h"
#include "Matrix4x4.h"
#include "MyMath.h"
#include "RenderingData.h"
#include "Model.h"
#include "Camera.h"
#include "Line.h"

struct EnvironmentReflectionSetting {
	float reflectionStrength = 1.0f; // 反射の強さ（0 = 無効、1 = 最大）
	float roughness = 0.0f;          // 反射のぼかし（0 = 鏡面、1 = ぼやけ）
	float padding[2] = {};           // HLSLと同様に16バイト境界を守るためのパディング
};

class Object3DCommon;
/// <summary>
/// 3Dオブジェクト
/// </summary>
class Object3D
{
public:
	/// <summary>
	/// 初期化
	/// </summary>
	void Initialize(Object3DCommon* object3DCommon);
	/// <summary>
	/// 更新
	/// </summary>
	void Update();
	/// <summary>
	/// スケルトン更新
	/// </summary>
	/// <param name="skeleton"></param>
	void SkeletonUpdate(Skeleton& skeleton);
	/// <summary>
	/// アニメーション適用
	/// </summary>
	/// <param name="skeleton"></param>
	void ApplyAnimation(Skeleton& skeleton, const Animation& animation, float animationTime);
	/// <summary>
	/// スキンクラスター更新
	/// </summary>
	/// <param name="skinCluster"></param>
	void SkinClusterUpdate(SkinCluster& skinCluster, const Skeleton& skeleton);
	/// <summary>
	/// 描画
	/// </summary>
	void Draw();
	/// <summary>
	/// スキニング描画
	/// </summary>
	void DrawSkinning();


	//アクセッサ

	/// <summary>
	/// モデルセット
	/// </summary>
	/// <param name="model"></param>
	void SetModel(Model* model) { model_ = model; }
	/// <summary>
	/// モデルセット(ファイルパスから)
	/// </summary>
	void SetModel(const std::string& filepath);
	/// <summary>
	//環境マップ
	/// </summary>
	/// <param name="filepath"></param>
	void SetSkyboxFilePath(const std::string& filepath) { skyboxFilePath_ = filepath; }
	/// <summary>
	/// 環境マップの反射強度設定
	/// </summary>
	/// <param name="reflectionStrength"></param>
	void SetReflectionStrengthforkankyouMap(float reflectionStrength) { environmentReflectionSettingData->reflectionStrength = reflectionStrength; }
	/// <summary>
	/// 環境マップの粗さ設定
	/// </summary>
	/// <param name="roughness"></param>
	void SetRoughnessForKankyouMap(float roughness) { environmentReflectionSettingData->roughness = roughness; }
	/// <summary>
	/// 環境マップの反射強度取得
	/// </summary>
	/// <returns></returns>
	float GetReflectionStrengthForKankyouMap() { return environmentReflectionSettingData->reflectionStrength; }
	/// <summary>
	/// 環境マップの粗さ取得
	/// </summary>
	/// <returns></returns>
	float GetRoughnessForKankyouMap() { return environmentReflectionSettingData->roughness; }

	/// <summary>
	/// トランスフォームセット
	/// </summary>
	/// <param name="transformValue"></param>
	/// <returns></returns>
	void SetTransform(const EulerTransform& transformValue) { this->transform = transformValue; }
	/// <summary>
	/// トランスフォーム取得
	/// </summary>
	/// <returns></returns>
	EulerTransform GetTransform() { return transform; }

	//アクセッサ

	//スケール
	void SetScale(const Vector3& scale) { transform.scale = scale; }
	//回転
	void SetRotate(const Vector3& rotate) { transform.rotate = rotate; }
	//位置
	void SetTranslate(const Vector3& translate) { transform.translate = translate; }
	//カメラ
	//void SetCamera(Camera* camera) { this->camera = camera; }
	////デフォルトカメラ

	//ディレクションライト
	void SetDirectionalLight(const DirectionalLight& directionalLight) { *directionalLightData = directionalLight; }
	DirectionalLight GetDirectionalLight() { return *directionalLightData; }
	//ディレクションライトの向き
	void SetDirectionalLightDirection(const Vector3& direction) { directionalLightData->direction = direction; }
	//ディレクションライトの色
	void SetDirectionalLightColor(const Vector4& color) { directionalLightData->color = color; }
	//ディレクションライトの強さ
	void SetDirectionalLightIntensity(float intensity) { directionalLightData->intensity = intensity; }
	//ライトオンオフ
	void SetDirectionalLightEnable(bool enable) { directionalLightData->enable = enable; }

	//ポイントライト
	void SetPointLight(const PointLight& pointLight) { *pointLightData = pointLight; }
	PointLight GetPointLight() { return *pointLightData; }
	//ポイントライトの位置
	void SetPointLightPosition(const Vector3& position) { pointLightData->position = position; }
	//ポイントライトの色
	void SetPointLightColor(const Vector4& color) { pointLightData->color = color; }
	//ポイントライトの強さ
	void SetPointLightIntensity(float intensity) { pointLightData->intensity = intensity; }
	//ポイントライトの半径
	void SetPointLightRadius(float radius) { pointLightData->radius = radius; }
	float GetPointLightRadius() { return pointLightData->radius; }
	//ポイントライトの減衰率
	void SetPointLightDecay(float decay) { pointLightData->decay = decay; }
	float GetPointLightDecay() { return pointLightData->decay; }
	//ポイントライトのオンオフ
	void SetPointLightEnable(bool enable) { pointLightData->enable = enable; }


	//スポットライト
	void SetSpotLight(const SpotLight& spotLight) { *spotLightData = spotLight; }
	SpotLight GetSpotLight() { return *spotLightData; }
	//スポットライトの位置
	void SetSpotLightPosition(const Vector3& position) { spotLightData->position = position; }
	//スポットライトの向き
	void SetSpotLightDirection(const Vector3& direction) { spotLightData->direction = direction; }
	//スポットライトの色
	void SetSpotLightColor(const Vector4& color) { spotLightData->color = color; }
	//スポットライトの強さ
	void SetSpotLightIntensity(float intensity) { spotLightData->intensity = intensity; }
	//スポットライトの距離
	void SetSpotLightDistance(float distance) { spotLightData->distance = distance; }
	//スポットライトの減衰率
	void SetSpotLightDecay(float decay) { spotLightData->decay = decay; }
	//スポットライトのコーンの角度
	void SetSpotLightConsAngle(float consAngle) { spotLightData->consAngle = consAngle; }

	void SetSpotLightCosFalloffstrt(float cosFalloffstrt) { spotLightData->cosFalloffstrt = cosFalloffstrt; }
	//スポットライトのオンオフ
	void SetSpotLightEnable(bool enable) { spotLightData->enable = enable; }

	//ライトのオンオフ
	void SetLighting(bool enable) { enableLighting = enable; }

	
	Vector4 GetColor() const { return color_; }

	//アニメーション
	Vector3 CalculateValue(const std::vector<KeyframeVector3>& keyframes, float time);
	Quaternion CalculateValue(const std::vector<KeyframeQuaternion>& keyframes, float time);



	//getワールドトランスフォーム
	Matrix4x4 GetWorldMatrix() { return worldMatrix; }




	/// <summary>
	//ライトのオンオフ
	/// </summary>	
	void SetEnableLighting(bool enable) { materialData->enableLighting = enable; }
	/// <summary>
	//色の設定
	/// </summary>
	// <param name="color"></param>
	void SetColor(const Vector4& color) { materialData->color = color; }

private:
	Object3DCommon* object3DCommon_ = nullptr;//Object3DCommonのポインタ

	Model* model_ = nullptr;//モデルのポインタ

	//トランスフォーム
	//ModelTransform用のリソースを作る。Matrix4x4 1つ分のサイズを用意する
	Microsoft::WRL::ComPtr<ID3D12Resource> transformationMatrixResource;
	//データを書き込む

	TransformationMatrix* transformationMatrixData = nullptr;


	//平行光源
	//平行光源用のResoureceを作成
	Microsoft::WRL::ComPtr<ID3D12Resource> directionalLightResource;
	DirectionalLight* directionalLightData = nullptr;

	//ポイントライト
	//ポイントライト用のリソースを作成
	Microsoft::WRL::ComPtr<ID3D12Resource> pointLightResource;
	PointLight* pointLightData = nullptr;

	//スポットライト
	//スポットライト用のリソースを作成
	Microsoft::WRL::ComPtr<ID3D12Resource> spotLightResource;
	SpotLight* spotLightData = nullptr;

	//SRT
	EulerTransform transform;
	Matrix4x4 worldMatrix;
	Matrix4x4 worldViewProjectionMatrix;

	//ライトのオンオフ
	bool enableLighting = true;
	//カメラ
	Camera* camera = nullptr;
	//カメラforGPU
	Microsoft::WRL::ComPtr<ID3D12Resource> cameraResource;//カメラのデータを送るためのリソース
	CaMeraForGpu* cameraForGpu = nullptr;//カメラのデータをGPUに送るための構造体
	//アニメーション
	float animationTime = 0.0f;
	bool enableAnimation_ = true;

	Vector4 color_ = { 1.0f, 1.0f, 1.0f, 1.0f }; // デフォルトは白
	Line line_; // Lineクラスのポインタ
	std::vector<Matrix4x4> skeletonPose_;

	std::string skyboxFilePath_; // スカイボックスのファイルパス

	std::string defaultEnvMapPath_ = "Resources/skyBox.dds";

	EnvironmentReflectionSetting* environmentReflectionSettingData; // 環境反射設定
	Microsoft::WRL::ComPtr<ID3D12Resource> environmentReflectionSettingResource;

	//マテリアル
	//modelマテリアる用のリソースを作る。今回color1つ分のサイズを用意する
	Microsoft::WRL::ComPtr<ID3D12Resource> materialResource;
	//マテリアルにデータを書き込む	
	Material* materialData = nullptr;

};

